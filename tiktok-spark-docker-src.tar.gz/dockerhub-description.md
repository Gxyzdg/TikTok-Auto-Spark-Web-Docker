# 抖音火花助手（TikTok Spark Auto Web For Docker）

自动维护抖音好友「火花」（连续互动标识）的个人学习项目：可视化 Web 管理后台，支持扫码 / 验证码 / Cookie 三种方式登录抖音，自动展示好友火花天数，一键发消息，或为好友创建每日定时发送任务，让火花不断档。

技术栈：Vue 3 + Element Plus（前端）· FastAPI + Selenium（后端）· 镜像内置 Chromium / chromedriver / VNC / noVNC，宿主机零依赖，开箱即用。

## 快速开始

```bash
docker pull gxyzdg/tiktok-spark-auto-web-for-docker:latest
docker tag gxyzdg/tiktok-spark-auto-web-for-docker:latest tiktok-spark:latest
docker compose up -d
```

> 或导入本地镜像包：`docker load -i tiktok-spark-latest.tar.gz`

## 端口

| 端口 | 用途 |
|------|------|
| 8080 | 前端管理后台（/api 已自动反代后端） |
| 6080 | noVNC 网页版 VNC（浏览器访问 http://IP:6080/ 看抖音窗口） |
| 5900 | VNC（扫码后滑块等二次验证手动操作） |
| 9844 | FastAPI 后端直连（调试用） |

## 默认信息

| 项目 | 默认值 |
|------|--------|
| 后台账户 | admin / 123456 |
| VNC 密码 | 123456 |

> ⚠️ 均为默认密码，仅便于演示/首次使用，正式使用前请务必修改。

## 使用流程

1. 浏览器打开 `http://<服务器IP>:8080/`，登录后台
2. 首页点「初始化浏览器」
3. 「设置」页扫码 / 验证码 / Cookie 登录抖音
4. 「定时任务」页为好友设置每日发送时间，自动续火花

## 免责声明

**仅供个人学习与研究使用。** 本项目通过自动化方式操作抖音，可能违反平台服务条款并触发风控，存在账号被限制甚至封禁的风险；使用本工具所产生的任何后果（含账号损失）均由使用者自行承担。
