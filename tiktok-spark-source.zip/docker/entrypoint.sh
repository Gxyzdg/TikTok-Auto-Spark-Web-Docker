#!/bin/bash
set -e

# 兜底默认值（docker-compose 已设，这里防止直接 docker run 时缺失）
export HOST="${HOST:-0.0.0.0}"
export PORT="${PORT:-9844}"
export DISPLAY="${DISPLAY:-:99}"
export CHROME_DRIVER_PATH="${CHROME_DRIVER_PATH:-/usr/bin/chromedriver}"
VNC_PASSWORD="${VNC_PASSWORD:-123456}"

echo "[entrypoint] 启动虚拟显示器 Xvfb (${DISPLAY}) ..."
# 屏幕尺寸与浏览器 window-size 一致；如需更小的 VNC 视图可自行调整
Xvfb "$DISPLAY" -screen 0 1400x3200x24 -ac +extension RANDR >/tmp/xvfb.log 2>&1 &
XVFB_PID=$!
sleep 1

echo "[entrypoint] 启动 VNC（端口 5900，密码: ${VNC_PASSWORD}）..."
x11vnc -display "$DISPLAY" -forever -shared -passwd "$VNC_PASSWORD" -rfbport 5900 -noxdamage >/tmp/x11vnc.log 2>&1 &
VNC_PID=$!

echo "[entrypoint] 启动 noVNC 网页版 VNC（端口 6080 -> 5900，浏览器访问 /vnc.html）..."
websockify --web=/usr/share/novnc 0.0.0.0:6080 127.0.0.1:5900 >/tmp/websockify.log 2>&1 &
NOVNC_PID=$!

echo "[entrypoint] 启动后端 uvicorn (${HOST}:${PORT}) ..."
python3 /app/抖音自动续火花-后端.py &
BACKEND_PID=$!

echo "[entrypoint] 启动 nginx ..."
nginx -g 'daemon off;' &
NGINX_PID=$!

# 等待 nginx 就绪（最多约 15s）
for _ in $(seq 1 15); do
    if curl -fsS http://127.0.0.1/ >/dev/null 2>&1; then break; fi
    sleep 1
done

# 在 VNC 里默认打开前端页面（可用环境变量 OPEN_FRONTEND_IN_VNC=0 关闭）
FRONTEND_BROWSER_PID=""
if [ "${OPEN_FRONTEND_IN_VNC:-1}" = "1" ]; then
    echo "[entrypoint] 在 VNC (${DISPLAY}) 打开前端页面 http://localhost/ ..."
    # 探测 chromium 二进制（不同镜像命名不同）
    CHROME_BIN=""
    for c in /usr/bin/chromium /usr/bin/chromium-browser /usr/bin/google-chrome; do
        if [ -x "$c" ]; then CHROME_BIN="$c"; break; fi
    done
    if [ -n "$CHROME_BIN" ]; then
        # 独立 profile（避免与 selenium 驱动的 Chrome 冲突）；--no-sandbox 因容器以 root 运行
        # 窗口放在屏幕底部（y=2300 起），与上方抖音窗口区域零重叠，避免遮挡/互相抬升
        "$CHROME_BIN" \
            --no-sandbox \
            --disable-dev-shm-usage \
            --no-first-run \
            --no-default-browser-check \
            --disable-session-crashed-bubble \
            --disable-infobars \
            --user-data-dir=/tmp/frontend-profile \
            --window-size=1400,900 \
            --window-position=0,2300 \
            "http://localhost/" >/tmp/frontend-browser.log 2>&1 &
        FRONTEND_BROWSER_PID=$!
    else
        echo "[entrypoint] 警告: 未找到 chromium 二进制，跳过 VNC 打开前端"
    fi
fi

cleanup() {
    echo "[entrypoint] 收到退出信号，清理进程..."
    [ -n "$FRONTEND_BROWSER_PID" ] && kill "$FRONTEND_BROWSER_PID" 2>/dev/null || true
    kill "$BACKEND_PID" "$NGINX_PID" "$VNC_PID" "$NOVNC_PID" "$XVFB_PID" 2>/dev/null || true
}
trap cleanup TERM INT

# 任一核心进程退出（崩溃）则整个容器退出，交给 Docker restart 策略自动拉起。
# 前端浏览器不属于核心进程：手动关掉它不会导致容器退出。
wait -n "$BACKEND_PID" "$NGINX_PID" "$VNC_PID" "$NOVNC_PID" "$XVFB_PID"
exit $?
